drop procedure pc_trol_tril;
drop procedure pc_qty_trol_tril_p;

